package com.cg.pizzaorder.bean;

import java.util.Date;

import com.cg.pizzaorder.ui.PizzaOrderMain;

public class PizzaOrder 
{
	private int orderid;
	private int customerId;
	private double totalPrice;
	private Date Orderdate;
	private  VegToppings toppings;
	

	public VegToppings getToppings() {
		return toppings;
	}
	public void setToppings(VegToppings toppings) {
		this.toppings = toppings;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public Date getOrderdate() {
		return Orderdate;
	}
	public void setOrderdate(Date orderdate) {
		Orderdate = orderdate;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public PizzaOrder( double totalPrice) {
		super();
	
	
		this.totalPrice = totalPrice;
	}
	public PizzaOrder() {
		// TODO Auto-generated constructor stub
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice)
	{
		this.totalPrice = totalPrice;
		
	}
	
}
